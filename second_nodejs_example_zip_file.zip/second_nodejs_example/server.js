const express = require("express")
const mongoose = require("mongoose")
// const ejs = require("ejs"); 
const bodyParser = require("body-parser"); 

const app=express();

const uri="mongodb+srv://premtheja31:Premarya31@cluster0.gcc5yeg.mongodb.net/?retryWrites=true&w=majority"

mongoose.set('strictQuery', true)
async function connect(){
    try{
        await mongoose.connect(uri);
        console.log("connected to mongodb")
    }catch (error){
        console.log("db error")
        console.log(error)
    }
}

connect()

const contactSchema = { 
    title: String, 
    id: Number 
  }; 

const Contact = mongoose.model("Contact", contactSchema);

app.set("view engine", "ejs"); 

app.use(bodyParser.urlencoded({ 
    extended: true
})); 

app.use(express.static(__dirname + '/public')); 



app.get("/contact", function(req, res){ 

    res.render("contact"); 
}); 

app.post("/contact", function (req, res) { 
    res.render("contact")
    console.log(req.body.title); 
  const contact = new Contact({ 
      title: req.body.title, 
      id: req.body.id, 
  }); 

  contact.save(function (err) { 
    if (err) { 
        throw err; 
    } else { 
      res.render("contact"); 
    } 
}); 
}); 

//read data from mongodb
app.get("/get", function(req, res){ 
    Contact.find((err,data)=>{
        if (err){
            return res.status(500).send(err)
        }else{
            return res.status(200).send(data)
            
        }
    })
  
}); 



app.listen(8000,()=>{
    console.log("server listening at port 8000")
})