const express=require("express")
const fs=require("fs").promises
const app=express()
var Gearman = require("node-gearman");
var gearman = new Gearman("localhost", 5000);
var job = gearman.submitJob("reverse", "test string");


gearman.on("connect", function(){
    console.log("Connected to the server!");
});
gearman.connect();

job.on("data", function(data){
    console.log(data.toString("utf-8")); // gnirts tset
});

job.on("end", function(){
    console.log("Job completed!");
});

job.on("error", function(error){
    console.log(error.message);
});

gearman.registerWorker("reverse", function(payload, worker){
    if(!payload){
        worker.error();
        return;
    }
    var reversed = payload.toString("utf-8").split("").reverse().join("");
    worker.end(reversed);
});

worker_path="E:\E42_assignments\05_gearman_celery_assignment\node_gearman_with_nodejs\node-files\worker.txt"
client_path="E:\E42_assignments\05_gearman_celery_assignment\node_gearman_with_nodejs\node-files\client.txt"
gearman.registerWorker("stream_file", function(payload, worker){
    var input = fs.createReadStream(worker_path);
    // stream file to client
    input.pipe(worker);
});

var job = gearman.submitJob("stream", null)
    // output = fs.createWriteStream(client_path); 

// save incoming stream to file
// job.pipe(output);

gearman.on("close", function(){
    console.log("Connection closed");
});

gearman.close();

app.get('/hello/', function(req, res) {
    res.send('Hello World!');
  });
  
var port = 5000
app.listen(port,function(){
    console.log(`app listening on port ${port}`);
  });