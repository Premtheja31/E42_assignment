from django.shortcuts import render
from django.http import HttpResponse
from .tasks import test_func
# Create your views here.
def test(request):
    if request.method=="POST":
        test_func.delay()
        return HttpResponse("<center><h1>MESSAGE RECIEVED</h1></center>")
    return render(request,"home.html")