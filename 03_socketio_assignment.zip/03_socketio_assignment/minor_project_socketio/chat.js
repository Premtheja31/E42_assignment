const app = require('express')();
const http = require('http').createServer(app);
const io = require('socket.io')(http);

app.get('/', (req, res) => {
  res.send('<center><h1>welcome to the minor project of socket.io</h1></center>');
});

app.get('/index1.html', (req, res) => {
  res.sendFile(__dirname + '/index1.html');
  console.log('user1 connected');
});

app.get('/index2.html', (req, res) => {
  res.sendFile(__dirname + '/index2.html');
  console.log('user2 connected');
});


io.on('connection', (socket) => {
  socket.on('chat message', (msg) => {
    console.log('message=> ' + msg);
    io.emit('chat message', msg);
  });
});

http.listen(5000, () => {
  console.log('Listening on port 5000');
});